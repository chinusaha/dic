var express = require('express')
var cfenv = require('cfenv')
var httpProxy = require('http-proxy');

var apiForwardingUrl = 'https://pbsa-prod.us-south.containers.mybluemix.net/840c1902-2e44-48d2-b3e9-f24e87de11f4/onboarding';
var apiDocStoreForwardingUrl = 'https://pbsa-prod.us-south.containers.mybluemix.net/840c1902-2e44-48d2-b3e9-f24e87de11f4';
var apiIACForwardingUrl = 'https://iac-api-server.mybluemix.net';
var apiContentForwardingUrl = 'https://pbsa-dev1.us-south.containers.mybluemix.net';
var app = express()
var appEnv = cfenv.getAppEnv();

app.use(express.static('dist'))
app.use(function (req, res, next) {
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
next();
});
var proxyOptions = {
    changeOrigin: true,
    secure:true
};

var apiProxy = httpProxy.createProxyServer(proxyOptions );

app.all("/v1/*", function(req, res) {
    console.log('redirecting to /v1/');
    apiProxy.web(req, res, {target: apiForwardingUrl });
});
app.all("/v0/*", function(req, res) {
    console.log('redirecting to /v0/');
    apiProxy.web(req, res, {target: apiIACForwardingUrl});
});
app.all("/docstore/*", function(req, res) {
    console.log('redirecting to /docstore/');
    apiProxy.web(req, res, {target: apiDocStoreForwardingUrl });
});
app.all("/contentshare/*", function(req, res) {
    console.log('redirecting to /contentshare/');
    apiProxy.web(req, res, {target: apiContentForwardingUrl });
});

app.all("/iac-dev/*", function(req, res) {
    console.log('redirecting to /contentshare/');
    apiProxy.web(req, res, {target: apiContentForwardingUrl });
});

app.get('/', function (req, res) {
  res.sendFile('./dist/index.html',{ root: __dirname });
})
app.get('/*', function (req, res) {
  res.sendFile('./dist/index.html',{ root: __dirname });
})

app.listen(appEnv.port, appEnv.bind, function () {
  console.log('Example app listening on port '+ appEnv.url)
})
